package org.concordion.internal;

import org.concordion.api.SpecificationLocatorWithType;

public class ClassNameAndTypeBasedSpecificationLocator extends ClassNameBasedSpecificationLocator implements SpecificationLocatorWithType {
}
