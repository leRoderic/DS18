package edu.ub.prog2.CabezasRodrigoNunezJosep.vista;

public class IniciadorAplicacioUB {

    public static void main(String[] args){
        AplicacioUB3 aplicacio = new AplicacioUB3();
        aplicacio.gestioAplicacioUB();
    }
}
