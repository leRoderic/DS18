package edu.ub.prog2.CabezasRodrigoNunezJosep.vista;

public class IniciadorAplicacioUB {
    public static void main(String[] args){  
        AplicacioUB4 aplicacio = new AplicacioUB4();        
    }
}
