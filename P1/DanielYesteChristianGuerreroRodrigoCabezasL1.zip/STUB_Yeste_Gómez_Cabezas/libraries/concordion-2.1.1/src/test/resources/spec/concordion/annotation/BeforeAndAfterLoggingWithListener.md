# Test class for Before and After

Log the message '[In specification](- "log(#TEXT)")'

## [Example 1] (- "example1")

Log the message '[In example 1](- "log(#TEXT)")'

## [Example 2] (- "example2")

Log the message '[In example 2](- "log(#TEXT)")'
