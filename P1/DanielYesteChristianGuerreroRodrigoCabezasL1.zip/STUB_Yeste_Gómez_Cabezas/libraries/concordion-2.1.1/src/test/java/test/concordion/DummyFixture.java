package test.concordion;

public class DummyFixture {

}