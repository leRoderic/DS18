package spec.concordion.common.command.assertEquals.whitespace;

import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;



@RunWith(ConcordionRunner.class)
public class NormalizationTest extends WhitespaceTest {

}
