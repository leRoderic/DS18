package org.concordion.api.listener;



public interface AssertEqualsListener extends AssertListener {

}
