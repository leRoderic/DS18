package org.concordion.api.listener;


public interface AssertTrueListener extends AssertListener {

}
